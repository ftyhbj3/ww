$(function () {
    //用户名字的前台验证
    $('#exampleInputName').blur(function () {

        var name = $(this).val();

        var reg = /^[a-z]{3,6}$/;

        b = reg.test(name);

        if(b){

            // $('#nameinfo').html('用户名可以使用').css({'color':'green','font-size':10});
            $.getJSON('/axfuser/checkName/',
                {'name':name},
                function (data) {
                    if(data['status'] == 200){
                        $('#nameinfo').html(data['msg']).css({'color':'green','font-size':10});
                    }else{
                        $('#nameinfo').html(data['msg']).css({'color':'red','font-size':10});
                    }
                })

        }else{
            $('#nameinfo').html('用户名格式不正确').css({'color':'red','font-size':10});
        }
    })

    //密码一致性
    $('#passordconfirm').blur(function () {
        var password = $('#password').val();
        var passwordconfim = $(this).val();

        if(password == passwordconfim){

        }else{
            $('#passwordinfo').html('密码不一致').css({'color':'red','font-size':10});
        }
    })

})



function parse1() {
    var password = document.getElementById('password').value;
    password = md5(password);

    document.getElementById('password').value=password;

    return true
}