$(function () {
    $('#pay').click(function () {
        window.location.href = '/axforder/testpay/';
    })
})