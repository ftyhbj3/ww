from django.apps import AppConfig


class MineappConfig(AppConfig):
    name = 'MineApp'
